# Architecture

Conceptual flow only:

```text
client -> queue -> processor -> webhook
```

Conceptual upload flow (illustrative, not runnable):

```text
client.upload_document -> upload-queue -> document-processor -> claim-service
```

Terminology aligns with the public SDK while remaining conceptual.

This is pseudocode, not runnable Python.
