# Upload Examples

Runnable examples only. These snippets are executable.

## Runnable example (minimal)

```python
from pyclaims import ClaimClient

client = ClaimClient(api_key="demo")
receipt = client.upload_document("sample.pdf")
print(receipt.document_id, receipt.status)
```

## Runnable example (explicit status)

```python
from pyclaims import ClaimClient

client = ClaimClient(api_key="demo")
receipt = client.upload_document("sample.pdf")
print("status:", receipt.status)
```

Notes:
- `upload_document(path)` returns an UploadReceipt with `document_id` and `status`.
- `status` defaults to `queued` in the current SDK implementation.
